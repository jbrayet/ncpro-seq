#!/usr/bin/python
# -*- coding: utf-8 -*-

# Copyleft ↄ⃝ 2012 Institut Curie
# Author(s): Jocelyn Brayet, Laurene Syx, Chongjian Chen, Nicolas Servant(Institut Curie) 2012 - 2015
# Contact: bioinfo.ncproseq@curie.fr
# This software is distributed without any guarantee under the terms of the GNU General
# Public License, either Version 2, June 1991 or Version 3, June 2007.

##
## This script downloads annotations and creates config-ncrna file for the ncPRO-seq tool.
##

import os

resultPath = "/usr/curie_ngs/ncPRO-seq_results/"

print("###################################################################################")
print("#				ncPRO-seq tool					  #")
print("###################################################################################\n")

projectName = raw_input("Please, give a project name : ")

print("Please, select the genome reference. All the samples have to belong to the same species.")
print("-----------------------------------------------------------")
print("|hg19		taeGut1		ornAna1		canFam2	  |")
print("|mm10		galGal3		monDom5		dm3	  |")
print("|mm9		rn4		rheMac2		bosTau4	  |")
print("|Zv9		rn5		equCab2		ce6	  |")
print("|TAIR9							  |")
print("-----------------------------------------------------------")

genomeAvailable = ['hg19', 'mm10', 'mm9', 'Zv9', 'TAIR9', 'galGal3', 'taeGut1', 'rn4', 'rn5', 'ornAna1', 'monDom5', 'rheMac2', 'equCab2', 'canFam2', 'dm3', 'bosTau4', 'ce6']

genomeRef = raw_input('Genome reference : ')

while not genomeRef in genomeAvailable :

    genomeRef = raw_input('Please, select correct genome reference : ')

dicGenome = {

    "hg19":"human_hg19.tar.gz",
    "mm10":"mouse_mm10.tar.gz",
    "mm9":"mouse_mm9.tar.gz",
    "Zv9":"zebrafish_Zv9.tar.gz",
    "TAIR9":"athaliana_TAIR9.tar.gz",
    "galGal3":"chicken_galGal3.tar.gz",
    "taeGut1":"zebrafinch_taeGut1.tar.gz",
    "rn4":"rat_rn4.tar.gz",
    "rn5":"rat_rn5.tar.gz",
    "ornAna1":"platypus_ornAna1.tar.gz",
    "monDom5":"opossum_monDom5.tar.gz",
    "rheMac2":"macaca_rheMac2.tar.gz",
    "equCab2":"horse_equCab2.tar.gz",
    "canFam2":"dog_canFam2.tar.gz",
    "dm3":"dmelanogaster_dm3.tar.gz",
    "bosTau4":"cow_bosTau4.tar.gz",
    "ce6":"celegans_ce6.tar.gz"

}



######## Link ########


cmdLine = "rm -rf /usr/curie_ngs/ncPRO-seq_results/rawdata; ln -s /usr/curie_ngs/rawdata/ /usr/curie_ngs/ncPRO-seq_results/rawdata"
os.system(cmdLine)
cmdLine = "rm -rf /usr/curie_ngs/ncPRO-seq_results/annotation; ln -s /usr/curie_ngs/annotation/ /usr/curie_ngs/ncPRO-seq_results/annotation"
os.system(cmdLine)

cmdLine = "cp -rf /usr/curie_ngs/ncproseq_v1.6.3/annotation/*.item /usr/curie_ngs/annotation/"
os.system(cmdLine)
cmdLine = "cp -rf /usr/curie_ngs/ncproseq_v1.6.3/annotation/*_items.txt /usr/curie_ngs/annotation/"
os.system(cmdLine)

######## Downloading genome ########

cmdLine = "cd "+resultPath+"annotation; wget "+dicGenome[genomeRef]+" http://sourceforge.net/projects/ncproseq/files/annotation/"+dicGenome[genomeRef]
os.system(cmdLine)
cmdLine = "cd "+resultPath+"annotation; tar -zxf "+dicGenome[genomeRef]
os.system(cmdLine)
cmdLine = "cd "+resultPath+"annotation; rm -rf "+dicGenome[genomeRef]
os.system(cmdLine)

######## Create good config-ncrna.txt ##########

annotationFiles = []
annoCatalog = ""

for file in os.listdir(resultPath+"annotation/"+genomeRef):
    if file.endswith(".gff"):
        annotationFiles.append(file)

if "cluster_pirna.gff" in annotationFiles :
    annoCatalog = resultPath+"annotation/"+genomeRef+"/precursor_miRNA.gff "+resultPath+"annotation/"+genomeRef+"/rfam.gff "+resultPath+"annotation/"+genomeRef+"/cluster_pirna.gff "+resultPath+"annotation/"+genomeRef+"/rmsk.gff "+resultPath+"annotation/"+genomeRef+"/coding_gene.gff"
else :
    if "pirna.gff" in annotationFiles :
        annoCatalog = resultPath+"annotation/"+genomeRef+"/precursor_miRNA.gff "+resultPath+"annotation/"+genomeRef+"/rfam.gff "+resultPath+"annotation/"+genomeRef+"/pirna.gff "+resultPath+"annotation/"+genomeRef+"/rmsk.gff "+resultPath+"annotation/"+genomeRef+"/coding_gene.gff"
    else :
        annoCatalog = resultPath+"annotation/"+genomeRef+"/precursor_miRNA.gff "+resultPath+"annotation/"+genomeRef+"/rfam.gff "+resultPath+"annotation/"+genomeRef+"/rmsk.gff "+resultPath+"annotation/"+genomeRef+"/coding_gene.gff"


cmdLine = "sed -i 's:^PROJECT_NAME.*$:PROJECT_NAME = "+projectName+":g' "+resultPath+"config-ncrna.txt"
os.system(cmdLine)
cmdLine = "sed -i 's:^BOWTIE_GENOME_REFERENCE.*$:BOWTIE_GENOME_REFERENCE = "+genomeRef+":g' "+resultPath+"config-ncrna.txt"
os.system(cmdLine)
cmdLine = "sed -i 's:^ORGANISM.*$:ORGANISM = "+genomeRef+":g' "+resultPath+"config-ncrna.txt"
os.system(cmdLine)
cmdLine = "sed -i 's:^ANNO_CATALOG.*$:ANNO_CATALOG = "+annoCatalog+":g' "+resultPath+"config-ncrna.txt"
os.system(cmdLine)


#print("\n###################################################################################")
#print("Your config-ncrna file is ready. If you want to add other parameters, you can open")
#print("config-ncrna.txt in this PATH :")
#print(resultPath)
#print("\nReminder :")
#print("\t- Download and add Bowtie indexes in this PATH : /ifb/curie_ngs/bowtie_indexes")
#print("\t- Download and add rawdata in this PATH : "+resultPath+"rawdata")
#print("\t- Recup ncPRO-seq results in this PATH : "+resultPath)
#print("\t- Run ncPRO-seq : ")
#print("\t\t- Go in results path : cd "+resultPath)
#print("\t\t- Run ncPRO-seq : /ifb/curie_ngs/ncproseq_v1.6.3/bin/ncPRO-seq -c config-ncrna.txt -s ")
#print("\n###################################################################################")

cmdLine = "cd "+resultPath+"; /usr/curie_ngs/ncproseq_v1.6.3/bin/ncPRO-seq -c config-ncrna.txt -s "
os.system(cmdLine)

cmdLine = "mkdir /usr/curie_ngs/results_host/"+projectName
os.system(cmdLine)

cmdLine = "mv -f /usr/curie_ngs/ncPRO-seq_results /usr/curie_ngs/results_host/"+projectName
os.system(cmdLine)

cmdLine = "rm -rf /usr/curie_ngs/results_host/"+projectName+"/ncPRO-seq_results/annotation"
os.system(cmdLine)

cmdLine = "rm -rf /usr/curie_ngs/results_host/"+projectName+"/ncPRO-seq_results/manuals"
os.system(cmdLine)

cmdLine = "rm -rf /usr/curie_ngs/results_host/"+projectName+"/ncPRO-seq_results/rawdata"
os.system(cmdLine)

print("\nCopyleft ↄ⃝ 2012 Institut Curie")
print("Author(s): Jocelyn Brayet, Laurene Syx, Chongjian Chen, Nicolas Servant(Institut Curie) 2012 - 2015")
print("Contact: bioinfo.ncproseq@curie.fr")
print("This software is distributed without any guarantee under the terms of the GNU General")
print("Public License, either Version 2, June 1991 or Version 3, June 2007.\n\n")




